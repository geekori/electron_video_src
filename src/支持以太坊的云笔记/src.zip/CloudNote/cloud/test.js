var fs  = require('fs');
var sd = require('silly-datetime');
var sql = require('./sql');
var filebuffer=fs.readFileSync('note.sqlite');
var db = new sql.Database(filebuffer);
var sql="delete from t_directory where mid='6f77be397d3d97cbc3ee66c412f9bac5' and directory_name='test1'";
console.log(sql)
db.run(sql);
var binaryArray = db.export();
var buffer = new Buffer(binaryArray);
fs.writeFileSync("note.sqlite", buffer);