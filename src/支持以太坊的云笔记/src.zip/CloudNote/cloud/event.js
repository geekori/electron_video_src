var dataBase = require('./conn');
var fs  = require('fs');
var setting = {	};
var treeflag={};
var zTree, rMenu;
var log, className = "dark";
global.setting = {//树配置
    view: {
        dblClickExpand: false
    },
    edit: {
        enable: true,
        showRemoveBtn: false,
        showRenameBtn: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    check: {
        enable: false
    },
    callback: {
        beforeClick: beforeClick,
        onClick: onClick,
        onRightClick: OnRightClick,
        beforeDrag: beforeDrag,
        beforeRemove: beforeRemove,
        beforeRename: beforeRename,
        onRemove: onRemove,
        onRename: onRename
    }
};
global.treeDemo='';
function onClick(event, treeId, treeNode, clickFlag) {//树插件里面的方法 点击节点
     treeflag.treeDemo=treeNode;
     var db=new dataBase();
     var text=db.loadNote(treeNode.id);
     if(text['text']=='Null'){
         UE.getEditor('editor').setContent('');
     }else{
         UE.getEditor('editor').setContent(text['text']);
     }

}
function beforeRemove(treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    zTree.selectNode(treeNode);
    return confirm("确认删除 节点 -- " + treeNode.name + " 吗？");
}
function onRemove(e, treeId, treeNode) {

}
function removeHoverDom(treeId, treeNode) {
    $("#"+treeNode.tId).unbind().remove();
};
function beforeClick(treeId, treeNode, clickFlag) {//树插件里面的方法

    return (treeNode.click != false);
}
function OnRightClick(event, treeId, treeNode) {
    if (!treeNode && event.target.tagName.toLowerCase() != "button" && $(event.target).parents("a").length == 0) {
        zTree.cancelSelectedNode();
        showRMenu("root", event.clientX, event.clientY);
    } else if (treeNode && !treeNode.noR) {
        zTree.selectNode(treeNode);
        showRMenu("node", event.clientX, event.clientY);
    }
}

function showRMenu(type, x, y) {
    $("#rMenu ul").show();
    if (type=="root") {
        $("#m_del").hide();
        $("#m_check").hide();
        $("#m_unCheck").hide();
    } else {
        $("#m_del").show();
        $("#m_check").show();
        $("#m_unCheck").show();
    }

    y += document.body.scrollTop;
    x += document.body.scrollLeft;
    rMenu.css({"top":y+"px", "left":x+"px", "visibility":"visible"});

    $("body").bind("mousedown", onBodyMouseDown);
}
function hideRMenu() {
    if (rMenu) rMenu.css({"visibility": "hidden"});
    $("body").unbind("mousedown", onBodyMouseDown);
}
function onBodyMouseDown(event){
    if (!(event.target.id == "rMenu" || $(event.target).parents("#rMenu").length>0)) {
        rMenu.css({"visibility" : "hidden"});
    }
}
var addCount = 1;
function addTreeNode() {
    hideRMenu();
    var newNode = { name:"增加" + (addCount++)};
    if (zTree.getSelectedNodes()[0]) {
        newNode.checked = zTree.getSelectedNodes()[0].checked;
        zTree.addNodes(zTree.getSelectedNodes()[0], newNode);
    } else {
        zTree.addNodes(null, newNode);
    }
}
function removeTreeNode() {
    hideRMenu();
    var nodes = zTree.getSelectedNodes();
    if (nodes && nodes.length>0) {
        if (nodes[0].children && nodes[0].children.length > 0) {
            var msg = "要删除的节点是父节点，如果删除将连同子节点一起删掉。\n\n请确认！";
            if (confirm(msg)==true){
                zTree.removeNode(nodes[0]);
            }
        } else {
            zTree.removeNode(nodes[0]);
        }
    }
}
function beforeDrag(treeId, treeNodes) {
    return false;
}
function beforeRemove(treeId, treeNode) {
    className = (className === "dark" ? "":"dark");
    showLog("[ "+getTime()+" beforeRemove ]&nbsp;&nbsp;&nbsp;&nbsp; " + treeNode.name);
    return confirm("确认删除 节点 -- " + treeNode.name + " 吗？");
}
function onRemove(e, treeId, treeNode) {
    showLog("[ "+getTime()+" onRemove ]&nbsp;&nbsp;&nbsp;&nbsp; " + treeNode.name);
}
function beforeRename(treeId, treeNode, newName) {
    if (newName.length == 0) {
        alert("节点名称不能为空.");
        var zTree = $.fn.zTree.getZTreeObj("treeDemo");
        setTimeout(function(){zTree.editName(treeNode)}, 10);
        return false;
    }
    return true;
}
function onRename(e, treeId, treeNode, isCancel) {
    console.log(treeNode);
    var name=treeNode.name;
    var mid=treeNode.id;
    var lastpath=treeNode.lastPath;
    var path=lastpath+name;
    var nmid=hex_md5(path);
    console.log("note:"+path+'----'+nmid);
    treeNode.id=nmid;
    var db=new dataBase();
    db.updateDirectory(name,nmid,mid);
}
function showLog(str) {
    if (!log) log = $("#log");
    log.append("<li class='"+className+"'>"+str+"</li>");
    if(log.children("li").length > 8) {
        log.get(0).removeChild(log.children("li")[0]);
    }
}
function getTime() {
    var now= new Date(),
        h=now.getHours(),
        m=now.getMinutes(),
        s=now.getSeconds(),
        ms=now.getMilliseconds();
    return (h+":"+m+":"+s+ " " +ms);
}

var newCount = 1;
function add(e) {
    hideRMenu();
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        isParent = e.data.isParent,
        nodes = zTree.getSelectedNodes(),
        treeNode = nodes[0];
    var pNode=treeNode;
    if (treeNode) {
        treeNode = zTree.addNodes(treeNode, {id:(100 + newCount), pId:treeNode.id, isParent:isParent,parentNode:pNode, name:"new node" + (newCount++)});
    } else {
        treeNode = zTree.addNodes(null, {id:(100 + newCount), pId:0, isParent:isParent,parentNode:pNode, name:"new node" + (newCount++)});
    }
    zTree.editName(treeNode[0]);
    if(isParent==true){
        var path='';
        while(true){
            if(pNode.id=='null') {
                path = '新建文件夹/' + path;
                break;
            }else{
                path=pNode.name+'/'+path;
            }

            pNode=pNode.parentNode;
        }
        console.log(treeNode)
        treeNode[0].lastPath=path;
        path=path+treeNode[0].name;
        //调用新建文件夹
        var name=treeNode[0].name;
        var mid=hex_md5(path);
        treeNode[0].id=mid;
        var pid=treeNode[0].pId;
        var type='1';
        var db=new dataBase();
        db.addDirectory(name,mid,pid,type);
    }else{
        var path='';
        while(1==1){
            if(pNode.id=='null') {
                path = '新建文件夹/' + path;
                break;
            }else{
                path=pNode.name+'/'+path;
            }

            pNode=pNode.parentNode;
        }
        treeNode[0].lastPath=path;
        path=path+treeNode[0].name;
        //调用新建文件夹
        var name=treeNode[0].name;
        var mid=hex_md5(path);
        console.log("note:"+path+'----'+mid);
        treeNode[0].id=mid;
        var pid=treeNode[0].pId;
        var type='2';
        var db=new dataBase();
        db.addDirectory(name,mid,pid,type);
    }
};
function del(e) {
    hideRMenu();
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        isParent = e.data.isParent,
        nodes = zTree.getSelectedNodes(),
        treeNode = nodes[0];
    console.log(treeNode)
    var mid=treeNode.id;
    var name=treeNode.name;
    var r=confirm("确认删除？")
    if(r==true){
        var db=new dataBase();
        db.del(name,mid);
        removeHoverDom(mid,treeNode)
    }
}
function edit() {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getSelectedNodes(),
        treeNode = nodes[0];
    if (nodes.length == 0) {
        alert("请先选择一个节点");
        return;
    }
    zTree.editName(treeNode);
};
function remove(e) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getSelectedNodes(),
        treeNode = nodes[0];
    if (nodes.length == 0) {
        alert("请先选择一个节点");
        return;
    }
    var callbackFlag = $("#callbackTrigger").attr("checked");
    zTree.removeNode(treeNode, callbackFlag);
};



function loadTree()
{
    var zNodes =[
        { name:"新建文件夹",directory_name:"新建文件夹",id:'null',isParent:true, open:true},
    ];
    var db=new dataBase();
    var data=db.query('t_directory');
    for(var i=0;i<data.length;i++) {
        if(data[i]['type']=='1'){
            if(data[i]['parent_id']=='null'){
                var obj = {
                    name: data[i]['directory_name'],
                    id: data[i]['mid'],
                    pId: data[i]['parent_id'],
                    parent_id:data[i]['parent_id'],
                    isParent: true,
                    parentNode:{ name:"新建文件夹",directory_name:"新建文件夹",id:'null', open:true}
                }
            }else{
                for(var a=0;a<data.length;a++){
                    if(data[i]['parent_id']==data[a]['mid']) {
                        var obj = {
                            name: data[i]['directory_name'],
                            directory_name: data[i]['directory_name'],
                            id: data[i]['mid'],
                            pId: data[i]['parent_id'],
                            parent_id:data[i]['parent_id'],
                            isParent: true
                        }
                    }
                }
            }

        }else{
            if(data[i]['parent_id']=='null'){
                var obj = {
                    name: data[i]['directory_name'],
                    directory_name: data[i]['directory_name'],
                    id: data[i]['mid'],
                    pId: data[i]['parent_id'],
                    isParent: false,
                    parentNode:{ name:"新建文件夹",directory_name:"新建文件夹",id:'null', open:true}
                }
            }else{
                for(var a=0;a<data.length;a++){
                    if(data[i]['parent_id']==data[a]['mid']) {
                        var obj = {
                            name: data[i]['directory_name'],
                            id: data[i]['mid'],
                            pId: data[i]['parent_id'],
                            isParent: false
                        }
                    }
                }
            }
        }
        zNodes.push(obj);
    }
    for(var i=0;i<zNodes.length;i++){
        for (var a=0;a<zNodes.length;a++){
            if(zNodes[i].pId==zNodes[a].id){
                zNodes[i].parentNode=zNodes[a];
            }
        }
    }
    console.log(zNodes);
    $.fn.zTree.init($("#treeDemo"), global.setting, zNodes);
    zTree = $.fn.zTree.getZTreeObj("treeDemo");
    rMenu = $("#rMenu");
}
$(document).ready(function(){
    if(fs.existsSync('username.txt')){
        var username=fs.readFileSync('username.txt',function (err) {
            console.log(err);
        });
        $('.user_name').show();
        $('.user_name').text(username.toString());
        $('.user_login').hide();
        $('.update_note').show();
    }else{
        $('.user_name').hide();
        $('.user_login').show();
        $('.update_note').hide();
    }


    loadTree();
    $("#addParent").bind("click", {isParent:true}, add);
    $("#addLeaf").bind("click", {isParent:false}, add);
    $("#del").bind("click", {isParent:false}, del);
    $("#btn_save").click(function(){

        var title=treeflag.treeDemo.name;
        var mid=treeflag.treeDemo.id;
        var text=UE.getEditor('editor').getContent();
        var db=new dataBase();
        db.addNote(title,mid,text);
    });
    $(document).keydown(function(e){
        if(e.keyCode==83&&e.ctrlKey){
            e.preventDefault();
            console.log(treeflag.treeDemo.name);
            var title = treeflag.treeDemo.name;
            var mid = treeflag.treeDemo.id;
            var text = UE.getEditor('editor').getContent();
            var db = new dataBase();
            db.addNote(title, mid, text);
        }
    });
    $(".btn1").click(function () {
        //  获取用户名
        var name=$(".lusername").val();
        //  获取密码
        var password=$(".lpassword").val();
        $.ajax({
            url:'http://localhost:3000/login',
            data:{name:name,password:password},
            dataType: "json",
            type:'post',
            success: function (result) {
                console.log(result);
                fs.writeFile('cookie.txt',result['_id'],function (err) { console.log(err);
                    loadTree();});
                fs.writeFile('username.txt',result['username'],function (err) {

                    console.log(err) });
                var username=result['username'];
                $('.user_name').show();
                $('.user_name').text(username.toString());
                $('.user_login').hide();
                $('.update_note').show();

                alert('登录成功！');

                $(".user").hide();
            },
            error:function (err) {
                console.log(err);
            }
        });
    });
    $(".update_note").click(function () {
        var db=new dataBase();
        //  查询本地的数据
        var result=db.query('t_directory');
        var userId=fs.readFileSync('cookie.txt',function (err) {
            console.log(err);
        });
        console.log(result);
        var data=[];
        result.forEach(function(item){
            var temp=[];
            temp[0]=item['_id'];
            temp[1]=item['user_id'];
            temp[2]=item['directory_name'];
            temp[3]=item['mid'];
            temp[4]=item['parent_id'];
            temp[5]=item['create_time'];
            temp[6]=item['type'];
            temp[7]=item['text'];
            data.push(JSON.stringify(temp));
        })
        //  将本地SQLite中的数据上传到服务端
        $.ajax({
            url:'http://localhost:3000/update',
            data:{data:data,id:userId.toString()},
            dataType: "json",
            traditional: true,//这里设置为true
            type:'post',
            success: function (result) {
                console.log(result);
            },
            error:function (err) {
                console.log(err);
            }
        });
        //  从服务端获取数据，将服务端的数据同步到本地
        $.ajax({
            url:'http://localhost:3000/tolocal',
            dataType: "json",
            traditional: true,//这里设置为true
            type:'post',
            success: function (result) {
                console.log(result);
                if(result.length>0){
                    var db=new dataBase();
                    db.update(result);
                }
            },
            error:function (err) {
                console.log(err);
            }
        });
        alert('同步成功');
    });
    $("#block").click(function(){
        hideRMenu();
        var mid=treeflag.treeDemo.id;
        console.log(mid)
        var db=new dataBase();
        var result=db.querynote(mid);
        var id=result[0]['mid'];
        var name=result[0]['directory_name'];
        var content=result[0]['text'];
        $.ajax({
            url:'http://localhost:5000/getNote',
            data:{id:id,name:name},
            dataType: "text",
            traditional: true,//这里设置为true
            type:'get',
            success: function (result) {
                alert('同步成功！');
                ue.setContent(result);
                var db=new dataBase();
                db.block(id,result)
            },
            error:function (err) {
                console.log(err);
            }
        });
    });
});
