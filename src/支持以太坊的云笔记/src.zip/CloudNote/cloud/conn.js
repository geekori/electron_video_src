var fs  = require('fs');
var sd = require('silly-datetime');
var sql = require('./sql');

class Database{
    constructor() {
        this.filebuffer=fs.readFileSync('note.sqlite');
        this.db = new sql.Database(this.filebuffer);
    }
    /******************users数据查询执行的方法*************************/
    query(name) {
        var data=[];
        var userId=this.getUserId()
        var sql="SELECT * FROM "+name+" where user_id="+userId;

        var result=this.db.exec(sql);
        if(result.length>0){
            var res=result[0];
            for(var i=0;i<res.values.length;i++){
                var val=res.values[i];
                var cols=[];
                for(var a=0;a<res.columns.length;a++){
                    var col=res.columns[a];
                    cols[col]=val[a];
                }
                data.push(cols);
            }
        }
        return data;
    }
    /******************users数据查询执行的方法*************************/
    querynote(mid) {
        var data=[];
        var user_id=this.getUserId();
        var sql="SELECT * FROM t_directory where user_id='"+user_id+"' and mid='"+mid+"'";
        console.log(sql)
        var result=this.db.exec(sql);
        if(result.length>0){
            var res=result[0];
            for(var i=0;i<res.values.length;i++){
                var val=res.values[i];
                var cols=[];
                for(var a=0;a<res.columns.length;a++){
                    var col=res.columns[a];
                    cols[col]=val[a];
                }
                data.push(cols);
            }
        }
        return data;
    }
    /*****************************插入数据************************/
    addDirectory(name, mid , pid,type) {
        var time=sd.format(new Date(), 'YYYY-MM-DD HH:mm');
        var user_id=this.getUserId();
        var text='Null';
        console.log("old:"+mid);
        this.db.run("INSERT INTO t_directory values(?,?,?,?,?,?,?,?)", [,user_id,name,mid,pid,time,type,text]);
        this.save();
    }
    updateDirectory(name,nmid, mid) {
        var user_id=this.getUserId();
        console.log("old:"+mid);
        console.log("new:"+nmid);
        var sql="UPDATE t_directory set directory_name='"+name+"' ,mid='"+nmid+"' where user_id='"+user_id+"' and mid='"+mid+"'";
        console.log(sql)
        this.db.run(sql);
        this.save();
    }
    block(mid,content) {
        var user_id=this.getUserId();
        var sql="UPDATE t_directory set text='"+content+"' where user_id='"+user_id+"' and mid='"+mid+"'";
        console.log(sql)
        this.db.run(sql);
        this.save();
    }
    /************************************添加笔记*****************************/
    addNote(title, mid,text){
        var user_id=this.getUserId();
        var stm=this.db.prepare("select * from t_directory where user_id=$user_id and mid=$mid");
        var result = stm.getAsObject({'$user_id' : user_id, '$mid' : mid});
        if(result['mid']==undefined){
            this.db.run("INSERT INTO t_note values(?,?,?,?,?)", [,user_id, mid, title,text]);
            this.save();
        }else{
            var sql="UPDATE t_directory set text='"+text+"' where user_id='"+user_id+"' and mid='"+mid+"'";
            console.log(sql)
            this.db.run(sql);
            this.save();
        }

    }
    /************************************加载笔记*****************************/
    loadNote(mid){
        var user_id=this.getUserId();
        var stm=this.db.prepare("select * from t_directory where user_id=$user_id and mid=$mid");
        var result = stm.getAsObject({'$user_id' : user_id, '$mid' : mid});
        return result;
    }
    getUserId(){
        if(fs.existsSync('cookie.txt')){
            var userId=fs.readFileSync('cookie.txt',function (err) {
                console.log(err);
            });
            return userId.toString();
        }else{
            return "0"
        }

    }
    update(data){
        var sqls='';
        data.forEach(function (item,index) {
            if(index==0){
                sqls+="\r\nselect '"+item['_id']+"','"+item['user_id']+"','"+item['directory_name']+"','"+item['mid']+"','"+item['parent_id']+"','"+item['create_time']+"','"+item['type']+"','"+item['content']+"'\r\n"
            }else {
                sqls += "\r\nunion ALL\r\nselect '" + item['_id'] + "','" + item['user_id'] + "','" + item['directory_name'] + "','" + item['mid'] + "','" + item['parent_id'] + "','" + item['create_time'] + "','" + item['type']+"','"+item['content']+"'\r\n"
            }
        });
        var sql="REPLACE INTO t_directory(_id,user_id,directory_name,mid,parent_id,create_time,type,text)";
        sql=sql+"\r\n"+sqls;
        this.db.run(sql);
        this.save();
    }
    del(name,mid){
        var sql="delete from t_directory where (mid='"+mid+"' and directory_name='"+name+"') or parent_id='"+mid+"'";
        console.log(sql)
        this.db.run(sql);
        this.save();
    }
    save(){
        //导出数据库
        console.log('save');
        var binaryArray = this.db.export();
        var buffer = new Buffer(binaryArray);
        fs.writeFileSync("note.sqlite", buffer);
    }
}
module.exports=Database;









