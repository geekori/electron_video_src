var jc = require('geekori_jc').jc;
console.log(jc(12))