var repeatStr = require('mystr').repeatStr
console.log(repeatStr("b",40))