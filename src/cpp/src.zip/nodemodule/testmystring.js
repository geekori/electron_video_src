//module.paths.push('/培训/在线培训/video/视频课程/Node.js/用C++和Go语言开发Node.js本地模块/源代码/node_nativemodule/documents')
module.paths = []
console.log(module)
require('fs')
/*var repeatStr = require('mystring').repeatStr;

console.log(repeatStr('a',20))*/

