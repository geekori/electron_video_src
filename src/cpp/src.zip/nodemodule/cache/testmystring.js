require('./mystring')
require('mystring')
require('/培训/在线培训/video/视频课程/Node.js/用C++和Go语言开发Node.js本地模块/源代码/node_nativemodule/src/nodemodule/cache/mystring.js')
var repeatStr = require('./mystring').repeatStr;

console.log(repeatStr('a',20))

