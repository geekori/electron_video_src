//var getValue = require('./build/Release/first').getValue;
var getValue = require('./first_electron').getValue;
console.log(getValue())

