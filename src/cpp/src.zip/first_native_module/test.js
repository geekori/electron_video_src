//var getValue = require('./build/Release/first').getValue;
var getValue = require('./build/Release/first').getValue;
console.log(getValue())

